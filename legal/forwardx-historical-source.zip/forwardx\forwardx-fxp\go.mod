module github.com/poouo/Forwardx/forwardx-fxp

go 1.22

require lukechampine.com/blake3 v1.4.1

require github.com/klauspost/cpuid/v2 v2.0.9 // indirect
